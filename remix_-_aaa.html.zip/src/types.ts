export interface Sensitivity {
  id: string;
  title: string;
  deviceType: string;
  code: string;
  dateAdded: string;
  description: string;
  isGyro: boolean;
  stats: {
    camera: string;
    ads: string;
    gyro: string;
    scope3x?: string;
    scope4x?: string;
    scope6x?: string;
  };
}

export interface ControlLayout {
  id: string;
  title: string;
  layoutType: string;
  code: string;
  dateAdded: string;
  description: string;
}

export interface PUBGNews {
  id: string;
  title: string;
  summary: string;
  content: string;
  dateAdded: string;
  category: 'news' | 'offer';
  badge?: string;
}

export interface UCCode {
  id: string;
  code: string;
  value: string;
  isAvailable: boolean;
  dateAdded: string;
  claimedAt?: string;
}

export interface DatabaseState {
  sensitivities: Sensitivity[];
  controls: ControlLayout[];
  news: PUBGNews[];
  ucCodes: UCCode[];
  adminPin: string;
}
