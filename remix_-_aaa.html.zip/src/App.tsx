/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Flame, 
  Smartphone, 
  Gamepad2, 
  KeyRound, 
  Tag, 
  CheckCircle2, 
  X, 
  TrendingUp, 
  AlertCircle, 
  Plus, 
  Trash2, 
  Edit, 
  Radio, 
  Cpu, 
  Clock, 
  Search, 
  Gift,
  ExternalLink,
  Lock,
  ChevronRight,
  Sparkles,
  Layers,
  Settings,
  HelpCircle,
  Copy
} from 'lucide-react';
import { DatabaseState, Sensitivity, ControlLayout, PUBGNews, UCCode } from './types';
import CopyButton from './components/CopyButton';

export default function App() {
  // Public data state
  const [data, setData] = useState<Omit<DatabaseState, 'adminPin'>>({
    sensitivities: [],
    controls: [],
    news: [],
    ucCodes: []
  });
  
  // Loading & notification states
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDeviceFilter, setSelectedDeviceFilter] = useState('الكل');
  
  // Active Navigation Tab
  const [activeTab, setActiveTab] = useState<'sensitivities' | 'controls' | 'uc' | 'news' | 'admin'>('sensitivities');
  
  // Admin State
  const [adminPin, setAdminPin] = useState('');
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminSection, setAdminSection] = useState<'sensitivities' | 'controls' | 'news' | 'uc' | 'settings'>('sensitivities');
  
  // Admin Form States
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newPin, setNewPin] = useState('');
  const [pingMs, setPingMs] = useState(24);

  // Form inputs for Sensitivities
  const [sensForm, setSensForm] = useState({
    title: '',
    deviceType: 'هواتف شاومي / بوكو',
    code: '',
    description: '',
    isGyro: true,
    camera: '120%',
    ads: '115%',
    gyro: '320%',
    scope3x: '200%',
    scope4x: '160%',
    scope6x: '90%'
  });

  // Form inputs for Control Layouts
  const [controlForm, setControlForm] = useState({
    title: '',
    layoutType: '4 أصابع',
    code: '',
    description: ''
  });

  // Form inputs for News & Offers
  const [newsForm, setNewsForm] = useState({
    title: '',
    summary: '',
    content: '',
    category: 'news' as 'news' | 'offer',
    badge: ''
  });

  // Form inputs for UC Code
  const [ucForm, setUcForm] = useState({
    code: '',
    value: '60 UC',
    isAvailable: true
  });

  // Fetch all public data on mount
  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/data');
      if (!res.ok) throw new Error("فشل جلب البيانات من السيرفر");
      const result = await res.json();
      setData(result);
      setError(null);
    } catch (err: any) {
      setError(err.message || "حدث خطأ غير متوقع");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    
    // Simulate real-time server ping adjustments for gaming look
    const interval = setInterval(() => {
      setPingMs(prev => {
        const diff = Math.floor(Math.random() * 7) - 3;
        const next = prev + diff;
        return next > 12 && next < 45 ? next : 24;
      });
    }, 4000);
    
    return () => clearInterval(interval);
  }, []);

  // Show a status notification
  const triggerNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Claim a UC Code
  const handleClaimUCCode = async (codeId: string) => {
    try {
      const res = await fetch('/api/uc-codes/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ codeId })
      });
      
      const result = await res.json();
      if (!res.ok) {
        throw new Error(result.error || "فشل الحصول على كود الشدات");
      }
      
      triggerNotification(result.message, 'success');
      // Refresh database
      fetchData();
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // Verify Admin Pin
  const handleAdminLogin = async (e: FormEvent) => {
    e.preventDefault();
    if (!adminPin) return;
    
    try {
      const res = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: adminPin })
      });
      
      const result = await res.json();
      if (res.ok && result.success) {
        setIsAdminAuthenticated(true);
        triggerNotification("مرحباً بك يا أدمن بروج فون! تم تسجيل الدخول بنجاح.", "success");
      } else {
        throw new Error(result.error || "رمز الأدمن غير صحيح");
      }
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // Change Admin Pin
  const handleChangePin = async (e: FormEvent) => {
    e.preventDefault();
    if (!newPin) return;
    
    try {
      const res = await fetch('/api/admin/change-pin', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'x-admin-pin': adminPin
        },
        body: JSON.stringify({ newPin })
      });
      
      const result = await res.json();
      if (res.ok && result.success) {
        setAdminPin(newPin);
        setNewPin('');
        triggerNotification("تم تغيير رمز الأمان السري للأدمن بنجاح!", "success");
      } else {
        throw new Error(result.error || "فشل تغيير الرمز");
      }
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // Log out Admin
  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    setAdminPin('');
    triggerNotification("تم تسجيل الخروج من لوحة الإدارة.", "success");
  };

  // Sensitivities Add/Edit Form Submit
  const handleSensSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const endpoint = editingId ? `/api/sensitivities/${editingId}` : '/api/sensitivities';
    const method = editingId ? 'PUT' : 'POST';
    
    const bodyData = {
      title: sensForm.title,
      deviceType: sensForm.deviceType,
      code: sensForm.code,
      description: sensForm.description,
      isGyro: sensForm.isGyro,
      stats: {
        camera: sensForm.camera,
        ads: sensForm.ads,
        gyro: sensForm.isGyro ? sensForm.gyro : 'غير مفعل',
        scope3x: sensForm.scope3x,
        scope4x: sensForm.scope4x,
        scope6x: sensForm.scope6x
      }
    };

    try {
      const res = await fetch(endpoint, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'x-admin-pin': adminPin
        },
        body: JSON.stringify(bodyData)
      });
      
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "فشل حفظ الحساسية");
      
      triggerNotification(editingId ? "تم تعديل الحساسية بنجاح!" : "تمت إضافة حساسية جديدة اليوم!", "success");
      
      // Reset Form
      setSensForm({
        title: '',
        deviceType: 'هواتف شاومي / بوكو',
        code: '',
        description: '',
        isGyro: true,
        camera: '120%',
        ads: '115%',
        gyro: '320%',
        scope3x: '200%',
        scope4x: '160%',
        scope6x: '90%'
      });
      setEditingId(null);
      fetchData();
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // Delete Sensitivity
  const handleSensDelete = async (id: string) => {
    if (!window.confirm("هل أنت متأكد من حذف كود الحساسية هذا نهائياً؟")) return;
    try {
      const res = await fetch(`/api/sensitivities/${id}`, {
        method: 'DELETE',
        headers: { 'x-admin-pin': adminPin }
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "فشل الحذف");
      
      triggerNotification("تم حذف كود الحساسية بنجاح", "success");
      fetchData();
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // Load Sensitivity for Editing
  const startEditSens = (sens: Sensitivity) => {
    setEditingId(sens.id);
    setSensForm({
      title: sens.title,
      deviceType: sens.deviceType,
      code: sens.code,
      description: sens.description,
      isGyro: sens.isGyro,
      camera: sens.stats.camera,
      ads: sens.stats.ads,
      gyro: sens.stats.gyro || '300%',
      scope3x: sens.stats.scope3x || '180%',
      scope4x: sens.stats.scope4x || '140%',
      scope6x: sens.stats.scope6x || '80%'
    });
  };

  // Control Layout Add/Edit Form Submit
  const handleControlSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const endpoint = editingId ? `/api/controls/${editingId}` : '/api/controls';
    const method = editingId ? 'PUT' : 'POST';

    try {
      const res = await fetch(endpoint, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'x-admin-pin': adminPin
        },
        body: JSON.stringify(controlForm)
      });
      
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "فشل حفظ مخطط الأزرار");
      
      triggerNotification(editingId ? "تم تعديل مخطط التحكم بنجاح!" : "تمت إضافة مخطط أزرار لعب جديد بنجاح!", "success");
      setControlForm({ title: '', layoutType: '4 أصابع', code: '', description: '' });
      setEditingId(null);
      fetchData();
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // Delete Control Layout
  const handleControlDelete = async (id: string) => {
    if (!window.confirm("هل تريد حذف هذا المخطط نهائياً؟")) return;
    try {
      const res = await fetch(`/api/controls/${id}`, {
        method: 'DELETE',
        headers: { 'x-admin-pin': adminPin }
      });
      if (!res.ok) throw new Error("فشل الحذف");
      
      triggerNotification("تم حذف كود مخطط الأزرار", "success");
      fetchData();
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // News & Offers Form Submit
  const handleNewsSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const endpoint = editingId ? `/api/news/${editingId}` : '/api/news';
    const method = editingId ? 'PUT' : 'POST';

    try {
      const res = await fetch(endpoint, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'x-admin-pin': adminPin
        },
        body: JSON.stringify(newsForm)
      });
      
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "فشل الحفظ");
      
      triggerNotification(editingId ? "تم تعديل الخبر بنجاح" : "تم نشر خبر وعروض ببجي جديدة!", "success");
      setNewsForm({ title: '', summary: '', content: '', category: 'news', badge: '' });
      setEditingId(null);
      fetchData();
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // Delete News / Offer
  const handleNewsDelete = async (id: string) => {
    if (!window.confirm("هل تريد حذف هذا الخبر؟")) return;
    try {
      const res = await fetch(`/api/news/${id}`, {
        method: 'DELETE',
        headers: { 'x-admin-pin': adminPin }
      });
      if (!res.ok) throw new Error("فشل الحذف");
      triggerNotification("تم حذف المنشور بنجاح", "success");
      fetchData();
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // UC Code Form Submit
  const handleUcSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const endpoint = editingId ? `/api/uc-codes/${editingId}` : '/api/uc-codes';
    const method = editingId ? 'PUT' : 'POST';

    try {
      const res = await fetch(endpoint, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'x-admin-pin': adminPin
        },
        body: JSON.stringify(ucForm)
      });
      
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "فشل حفظ كود الـ UC");
      
      triggerNotification(editingId ? "تم تعديل كود الشحن" : "تمت إضافة كود شدات ببجي مجاني جديد!", "success");
      setUcForm({ code: '', value: '60 UC', isAvailable: true });
      setEditingId(null);
      fetchData();
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // Delete UC Code
  const handleUcDelete = async (id: string) => {
    if (!window.confirm("هل تريد حذف كود الـ UC هذا؟")) return;
    try {
      const res = await fetch(`/api/uc-codes/${id}`, {
        method: 'DELETE',
        headers: { 'x-admin-pin': adminPin }
      });
      if (!res.ok) throw new Error("فشل الحذف");
      triggerNotification("تم حذف كود الشدات من السيرفر", "success");
      fetchData();
    } catch (err: any) {
      triggerNotification(err.message, 'error');
    }
  };

  // Filtering sensitivities
  const filteredSensitivities = data.sensitivities.filter(sens => {
    const matchesSearch = 
      sens.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sens.deviceType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sens.code.includes(searchQuery);
    
    if (selectedDeviceFilter === 'الكل') return matchesSearch;
    if (selectedDeviceFilter === 'جايروسكوب') return matchesSearch && sens.isGyro;
    if (selectedDeviceFilter === 'أصابع فقط') return matchesSearch && !sens.isGyro;
    return matchesSearch && sens.deviceType.includes(selectedDeviceFilter);
  });

  return (
    <div className="min-h-screen bg-[#0c0c0c] text-white font-sans flex flex-col selection:bg-[#00ff00] selection:text-black">
      
      {/* Top Warning/Ticker Notification */}
      <AnimatePresence>
        {notification && (
          <motion.div 
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-4 left-4 right-4 z-50 max-w-md mx-auto"
            id="toast-notification"
          >
            <div className={`p-4 rounded-xl border-2 shadow-2xl flex items-start gap-3 ${
              notification.type === 'success' 
                ? 'bg-black border-[#00ff00] text-white' 
                : 'bg-black border-[#ff6321] text-white'
            }`}>
              {notification.type === 'success' ? (
                <CheckCircle2 className="w-6 h-6 text-[#00ff00] shrink-0" />
              ) : (
                <AlertCircle className="w-6 h-6 text-[#ff6321] shrink-0" />
              )}
              <div className="flex-1">
                <p className="font-bold text-sm">نظام بروج فون الذكي:</p>
                <p className="text-xs text-gray-300 mt-1">{notification.message}</p>
              </div>
              <button onClick={() => setNotification(null)} className="text-gray-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Header / Navigation */}
      <header className="border-b-2 border-[#1f1f1f] bg-black/95 sticky top-0 z-40 px-4 sm:px-8 py-4 flex flex-col md:flex-row items-center justify-between gap-4" id="main-header">
        <div className="flex flex-col sm:flex-row items-center gap-6 w-full md:w-auto">
          {/* Logo with cyberpunk skew styling */}
          <div className="flex items-center gap-2">
            <div className="text-3xl sm:text-4xl font-extrabold tracking-tighter text-[#00ff00] skew-x-[-12deg] select-none bg-gradient-to-r from-[#00ff00] to-[#10b981] bg-clip-text text-transparent">
              بروج فون
            </div>
            <span className="bg-[#ff6321] text-black text-[9px] font-black uppercase px-1.5 py-0.5 rounded skew-x-[-12deg]">
              PUBG
            </span>
          </div>
          
          {/* Desktop/Tablet Navigation Links */}
          <nav className="flex flex-wrap justify-center gap-1 sm:gap-2 text-xs sm:text-sm font-bold uppercase tracking-wider text-gray-400 w-full sm:w-auto" id="main-nav">
            <button 
              onClick={() => setActiveTab('sensitivities')}
              className={`px-3 py-2 rounded-lg transition-all cursor-pointer ${
                activeTab === 'sensitivities' 
                  ? 'text-white bg-[#00ff00]/10 border-b-2 border-[#00ff00]' 
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              أكواد الحساسية
            </button>
            <button 
              onClick={() => setActiveTab('controls')}
              className={`px-3 py-2 rounded-lg transition-all cursor-pointer ${
                activeTab === 'controls' 
                  ? 'text-white bg-[#00ff00]/10 border-b-2 border-[#00ff00]' 
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              طريقة اللعب والأزرار
            </button>
            <button 
              onClick={() => setActiveTab('uc')}
              className={`px-3 py-2 rounded-lg transition-all relative cursor-pointer ${
                activeTab === 'uc' 
                  ? 'text-white bg-[#ff6321]/10 border-b-2 border-[#ff6321]' 
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              شدات مجانية
              <span className="absolute -top-1 -left-2 bg-[#ff6321] text-black text-[8px] font-black px-1 rounded animate-pulse">
                جديد
              </span>
            </button>
            <button 
              onClick={() => setActiveTab('news')}
              className={`px-3 py-2 rounded-lg transition-all cursor-pointer ${
                activeTab === 'news' 
                  ? 'text-white bg-[#00ff00]/10 border-b-2 border-[#00ff00]' 
                  : 'hover:text-white hover:bg-white/5'
              }`}
            >
              أخبار وعروض ببجي
            </button>
            <button 
              onClick={() => setActiveTab('admin')}
              className={`px-3 py-2 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                activeTab === 'admin' 
                  ? 'text-white bg-purple-500/10 border-b-2 border-purple-500' 
                  : 'hover:text-white hover:bg-white/5 text-purple-400'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>لوحة التحكم (أدمن)</span>
            </button>
          </nav>
        </div>

        {/* Server status & Admin state */}
        <div className="flex items-center gap-4 shrink-0 w-full sm:w-auto justify-between sm:justify-end border-t border-[#1f1f1f] sm:border-t-0 pt-3 sm:pt-0">
          <div className="px-3 py-1.5 bg-[#121212] rounded-lg border border-[#222] text-[11px] font-mono flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00ff00] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00ff00]"></span>
            </span>
            <span className="text-gray-400">سيرفر خارجي:</span>
            <span className="text-[#00ff00] font-bold">نشط ({pingMs}ms)</span>
          </div>

          <div className="flex items-center gap-2">
            {isAdminAuthenticated ? (
              <div className="flex items-center gap-2">
                <span className="text-[10px] bg-purple-900/40 text-purple-300 border border-purple-500 px-2 py-1 rounded">
                  أدمن متصل
                </span>
                <button 
                  onClick={handleAdminLogout} 
                  className="bg-red-950/40 hover:bg-red-900/60 text-red-300 text-xs px-2.5 py-1.5 rounded-lg border border-red-800 transition-all cursor-pointer"
                >
                  خروج
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setActiveTab('admin')} 
                className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#00ff00] to-teal-500 flex items-center justify-center text-black font-extrabold text-xs shadow-lg shadow-[#00ff00]/15 hover:scale-105 transition-transform cursor-pointer"
                title="لوحة الإدارة"
              >
                PRO
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Viewport Layout */}
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden" id="main-content">
        
        {/* RIGHT/PRIMARY PANEL - Content display depending on active tabs */}
        <section className="flex-1 p-4 sm:p-8 flex flex-col overflow-y-auto min-h-[400px]">
          
          {/* Header section with stats & title */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8 pb-6 border-b border-[#222]" id="section-intro">
            <div>
              <div className="text-[10px] sm:text-xs text-[#00ff00] font-mono tracking-widest uppercase mb-1 flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 animate-pulse text-[#00ff00]" />
                <span>بروج فون • تحديث يومي فوري لأجهزة الأندرويد</span>
              </div>
              
              {activeTab === 'sensitivities' && (
                <>
                  <h1 className="text-4xl sm:text-5xl font-black italic uppercase leading-none tracking-tight text-white">
                    أكواد الحساسية <span className="text-[#00ff00] not-italic">PUBG</span>
                  </h1>
                  <p className="text-gray-400 mt-2 text-sm max-w-xl">
                    إليك أفضل أكواد حساسية ببجي موبايل المجربة والمحدثة يومياً لتثبيت الأيم وزيادة نسبة الهيدشوت. تدعم الجايروسكوب والأصابع لجميع المعالجات.
                  </p>
                </>
              )}

              {activeTab === 'controls' && (
                <>
                  <h1 className="text-4xl sm:text-5xl font-black italic uppercase leading-none tracking-tight text-white">
                    أكواد طريقة اللعب والأزرار
                  </h1>
                  <p className="text-gray-400 mt-2 text-sm max-w-xl">
                    احصل على أفضل مخططات توزيع أزرار التحكم ببجي (إصبعين، 3 أصابع، 4 أصابع، و 5 أصابع) لتسريع حركتك وسرعة الاستجابة لديك.
                  </p>
                </>
              )}

              {activeTab === 'uc' && (
                <>
                  <h1 className="text-4xl sm:text-5xl font-black italic uppercase leading-none tracking-tight text-white">
                    أكواد شدات ببجي مجانية <span className="text-[#ff6321] not-italic">UC</span>
                  </h1>
                  <p className="text-gray-400 mt-2 text-sm max-w-xl">
                    هدايا زوار موقع بروج فون الأوفياء! نقوم بنشر وتحديث أكواد شحن شدات مجانية يومياً. احصل على كودك الآن واشحنه عبر موقع اللعبة الرسمي مجاناً.
                  </p>
                </>
              )}

              {activeTab === 'news' && (
                <>
                  <h1 className="text-4xl sm:text-5xl font-black italic uppercase leading-none tracking-tight text-white">
                    أخبار وعروض ببجي موبايل
                  </h1>
                  <p className="text-gray-400 mt-2 text-sm max-w-xl">
                    متابعة يومية مستمرة لأحدث التسريبات والتحديثات القادمة، عروض الشحن بالشرق الأوسط، ودورات ببجي الحماسية.
                  </p>
                </>
              )}

              {activeTab === 'admin' && (
                <>
                  <h1 className="text-4xl sm:text-5xl font-black italic uppercase leading-none tracking-tight text-white">
                    لوحة تحكم الأدمن
                  </h1>
                  <p className="text-gray-400 mt-2 text-sm max-w-xl">
                    إدارة محتوى موقع بروج فون: تعديل وتحديث أكواد الحساسية، إضافة أكواد الأزرار، نشر الأخبار، وتزويد الزوار بأكواد شدات مجانية.
                  </p>
                </>
              )}
            </div>

            {/* Daily updates count down & quick stats */}
            <div className="bg-[#121212] p-4 rounded-xl border border-[#222] min-w-[200px] flex justify-between items-center shrink-0">
              <div className="text-right">
                <div className="text-2xl font-mono text-[#00ff00] tracking-wider animate-pulse">00:12:45</div>
                <div className="text-[10px] text-gray-500 uppercase font-bold mt-1">وقت التحديث التلقائي القادم</div>
              </div>
              <Clock className="w-8 h-8 text-orange-500" />
            </div>
          </div>

          {/* SENSITIVITIES TAB CONTENT */}
          {activeTab === 'sensitivities' && (
            <div className="flex-1 flex flex-col gap-6" id="sens-tab">
              {/* Filter bar */}
              <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-[#111] p-4 rounded-xl border border-[#222]">
                <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                  {['الكل', 'شاومي', 'سامسونج', 'جايروسكوب', 'أصابع فقط'].map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setSelectedDeviceFilter(filter)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        selectedDeviceFilter === filter 
                          ? 'bg-[#00ff00] text-black shadow-lg shadow-[#00ff00]/20' 
                          : 'bg-[#1a1a1a] text-gray-400 hover:text-white hover:bg-[#222]'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>

                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="text"
                    placeholder="ابحث عن هاتف أو حساسية..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#181818] border border-[#333] rounded-lg pr-10 pl-3 py-2 text-xs focus:outline-none focus:border-[#00ff00] text-white"
                  />
                </div>
              </div>

              {loading ? (
                <div className="py-20 text-center text-gray-500">جاري تحميل أحدث أكواد الحساسية اليومية...</div>
              ) : filteredSensitivities.length === 0 ? (
                <div className="py-16 text-center bg-[#111] rounded-2xl border border-dashed border-[#222]">
                  <Smartphone className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                  <p className="text-gray-400 font-bold">لا توجد أكواد حساسية تطابق بحثك حالياً</p>
                  <p className="text-gray-600 text-xs mt-1">سيتم إضافة المزيد من الأكواد قريباً عبر الأدمن</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  {filteredSensitivities.map((sens, idx) => (
                    <div 
                      key={sens.id}
                      className="border-2 border-white/10 hover:border-white p-6 rounded-2xl bg-black/40 flex flex-col justify-between transition-all group relative overflow-hidden"
                      id={`sens-card-${sens.id}`}
                    >
                      {/* Badge in corner */}
                      <div className="absolute top-0 left-0 bg-[#00ff00] text-black font-black text-[9px] px-3 py-1 rounded-br-xl uppercase skew-x-[-12deg]">
                        {sens.deviceType}
                      </div>

                      <div className="flex justify-between items-start mb-4">
                        <span className="text-3xl font-black text-gray-700 select-none">0{idx + 1}</span>
                        <div className="flex gap-2">
                          <span className={`text-[10px] font-bold px-2 py-1 rounded border ${
                            sens.isGyro 
                              ? 'border-[#00ff00]/40 text-[#00ff00] bg-[#00ff00]/5' 
                              : 'border-blue-500/40 text-blue-400 bg-blue-500/5'
                          }`}>
                            {sens.isGyro ? "جايروسكوب نشط" : "بدون جايروسكوب"}
                          </span>
                          <span className="text-[10px] text-gray-500 bg-[#161616] px-2 py-1 rounded">
                            تحديث: {sens.dateAdded}
                          </span>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-bold text-white mb-2 group-hover:text-[#00ff00] transition-colors leading-relaxed">
                          {sens.title}
                        </h3>
                        <p className="text-xs text-gray-400 mb-4 line-clamp-2 leading-relaxed">
                          {sens.description}
                        </p>

                        {/* Quick Stats visualizer */}
                        <div className="grid grid-cols-3 gap-2 bg-[#121212] p-3 rounded-xl border border-[#222] mb-4 text-center">
                          <div>
                            <span className="block text-[10px] text-gray-500 mb-0.5">كاميرا</span>
                            <span className="text-xs font-bold font-mono text-white">{sens.stats.camera}</span>
                          </div>
                          <div>
                            <span className="block text-[10px] text-gray-500 mb-0.5">ADS</span>
                            <span className="text-xs font-bold font-mono text-[#00ff00]">{sens.stats.ads}</span>
                          </div>
                          <div>
                            <span className="block text-[10px] text-gray-500 mb-0.5">جايروسكوب</span>
                            <span className="text-xs font-bold font-mono text-orange-500">{sens.stats.gyro}</span>
                          </div>
                        </div>

                        {/* Optional scope parameters display */}
                        {(sens.stats.scope3x || sens.stats.scope4x || sens.stats.scope6x) && (
                          <div className="flex justify-around bg-black/30 py-2 px-3 rounded-lg border border-[#1a1a1a] mb-5 text-[11px] text-gray-400">
                            {sens.stats.scope3x && <span>سكوب 3x: <strong className="text-white font-mono">{sens.stats.scope3x}</strong></span>}
                            {sens.stats.scope4x && <span>سكوب 4x: <strong className="text-white font-mono">{sens.stats.scope4x}</strong></span>}
                            {sens.stats.scope6x && <span>سكوب 6x: <strong className="text-[#00ff00] font-mono">{sens.stats.scope6x}</strong></span>}
                          </div>
                        )}

                        {/* Code box and copy trigger */}
                        <div className="flex items-center justify-between gap-3 bg-[#161616] p-3 rounded-xl border border-[#222]">
                          <div className="text-right">
                            <span className="block text-[9px] text-gray-500 uppercase tracking-widest font-bold">كود المشاركة الفوري</span>
                            <span className="text-sm font-mono font-bold tracking-wider text-orange-400 select-all">{sens.code}</span>
                          </div>
                          <CopyButton text={sens.code} label="نسخ الكود" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* CONTROLS TAB CONTENT */}
          {activeTab === 'controls' && (
            <div className="flex-1 flex flex-col gap-6" id="controls-tab">
              {loading ? (
                <div className="py-20 text-center text-gray-500">جاري تحميل مخططات أزرار اللعب الاحترافية...</div>
              ) : data.controls.length === 0 ? (
                <div className="py-16 text-center bg-[#111] rounded-2xl border border-dashed border-[#222]">
                  <Gamepad2 className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                  <p className="text-gray-400 font-bold">لم يتم نشر مخططات أزرار حالياً</p>
                  <p className="text-gray-600 text-xs mt-1">ترقب إضافة مخططات 3، 4، 5 أصابع مع كود المخطط قريباً</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {data.controls.map((layout, idx) => (
                    <div 
                      key={layout.id}
                      className="border-2 border-white/10 hover:border-white p-6 rounded-2xl bg-[#111]/40 flex flex-col justify-between transition-colors group relative"
                    >
                      <div className="absolute top-4 left-4 bg-orange-600 text-white text-[10px] font-black px-2.5 py-1 rounded uppercase">
                        مخطط {layout.layoutType}
                      </div>

                      <div className="mb-6">
                        <span className="text-4xl font-black text-gray-800">0{idx + 1}</span>
                        <h3 className="text-lg font-bold text-white mt-2 mb-3 leading-snug group-hover:text-orange-500 transition-colors">
                          {layout.title}
                        </h3>
                        <p className="text-xs text-gray-400 leading-relaxed mb-4">
                          {layout.description}
                        </p>
                      </div>

                      <div>
                        {/* Play style illustrative guide */}
                        <div className="bg-black/60 p-3 rounded-xl border border-[#222] mb-4 text-xs text-gray-400 space-y-2">
                          <div className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                            <span>المنطقة اليسرى: الحركة السريعة + فتح الحقيبة</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                            <span>المنطقة اليمنى: إطلاق النار المزدوج + تفعيل البيك (الانحناء)</span>
                          </div>
                        </div>

                        {/* Code box */}
                        <div className="flex items-center justify-between gap-3 bg-[#161616] p-3 rounded-xl border border-[#222]">
                          <div>
                            <span className="block text-[9px] text-gray-500 font-bold">كود المخطط</span>
                            <span className="text-xs font-mono font-bold tracking-wider text-[#00ff00] select-all">{layout.code}</span>
                          </div>
                          <CopyButton text={layout.code} label="نسخ مخطط اللعب" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* UC FREE CODES TAB */}
          {activeTab === 'uc' && (
            <div className="flex-1 flex flex-col gap-6" id="uc-tab">
              {/* Promotion banner inside UC */}
              <div className="p-6 bg-gradient-to-r from-orange-600/30 via-red-600/15 to-transparent rounded-2xl border-2 border-[#ff6321]/40 relative overflow-hidden flex flex-col sm:flex-row items-center gap-6">
                <div className="w-16 h-16 bg-[#ff6321] rounded-2xl flex items-center justify-center text-black font-black text-4xl shrink-0 shadow-lg shadow-orange-500/20">
                  UC
                </div>
                <div className="text-center sm:text-right flex-1">
                  <span className="bg-[#ff6321] text-black text-[10px] font-black uppercase px-2 py-0.5 rounded skew-x-[-12deg]">
                    مجاني 100%
                  </span>
                  <h2 className="text-xl font-bold text-white mt-1.5">مكافآت يومية لزوارنا الكرام</h2>
                  <p className="text-xs text-gray-400 mt-1 max-w-xl">
                    كل 24 ساعة، نقوم بوضع كروت شدات جديدة. اختر الكود المتوفر واضغط على "استلام والحصول على الشدات". بعد نسخ الكود، يمكنك تفعيله في موقع ببجي الرسمي Midasbuy.
                  </p>
                </div>
                <div className="absolute -bottom-10 -left-10 text-[100px] font-black italic opacity-5 pointer-events-none select-none">
                  FREE
                </div>
              </div>

              {loading ? (
                <div className="py-20 text-center text-gray-500">جاري فحص وتحديث أكواد الشدات النشطة...</div>
              ) : data.ucCodes.length === 0 ? (
                <div className="py-16 text-center bg-[#111] rounded-2xl border border-dashed border-[#222]">
                  <Gift className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                  <p className="text-gray-400 font-bold">لا توجد أكواد شدات حالياً</p>
                  <p className="text-gray-600 text-xs mt-1">يقوم الأدمن بوضع الكروت والشدات المجانية بشكل دوري متقطع خلال اليوم</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {data.ucCodes.map((uc) => (
                    <div 
                      key={uc.id}
                      className={`border-2 p-6 rounded-2xl flex flex-col justify-between transition-all relative ${
                        uc.isAvailable 
                          ? 'border-[#ff6321]/30 hover:border-[#ff6321] bg-black/50' 
                          : 'border-[#222] bg-black/20 opacity-60'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full ${uc.isAvailable ? 'bg-[#00ff00]' : 'bg-red-500'}`}></span>
                          <span className="text-xs font-bold text-gray-400">
                            {uc.isAvailable ? "متوفر للاستخدام" : "تم استلامه واستخدامه"}
                          </span>
                        </div>
                        <span className="text-xs text-gray-600 font-mono">{uc.dateAdded}</span>
                      </div>

                      <div className="mb-6">
                        <div className="text-3xl font-black font-mono text-white mb-1 flex items-baseline gap-1">
                          <span>{uc.value.split(' ')[0]}</span>
                          <span className="text-xs text-[#ff6321] font-sans">{uc.value.split(' ')[1] || 'UC'}</span>
                        </div>
                        <p className="text-[11px] text-gray-500 mt-1">
                          {uc.isAvailable 
                            ? "اضغط على الزر أدناه لحجز واستلام الكود مجاناً فوراً."
                            : `تم حجز الكود من قبل مستخدم آخر في ${uc.claimedAt ? new Date(uc.claimedAt).toLocaleTimeString('ar-EG', {hour: '2-digit', minute:'2-digit'}) : ''}`
                          }
                        </p>
                      </div>

                      {/* Redeem code visual block */}
                      <div className="mt-auto">
                        {uc.isAvailable ? (
                          <button
                            onClick={() => handleClaimUCCode(uc.id)}
                            className="w-full bg-[#ff6321] hover:bg-orange-500 text-black font-black py-2.5 rounded-xl text-xs uppercase tracking-wider transition-all duration-200 active:scale-95 shadow-lg shadow-orange-500/10 hover:shadow-orange-500/20 flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <Gift className="w-4 h-4" />
                            <span>احصل على الشدات مجاناً</span>
                          </button>
                        ) : (
                          <div className="bg-[#151515] p-3 rounded-xl border border-[#222] text-center">
                            <span className="block text-[10px] text-gray-500 font-bold mb-1">الكود المستهلك</span>
                            <span className="text-xs font-mono font-bold text-gray-500 line-through tracking-widest">{uc.code.substring(0, 8)}...</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Midasbuy Guide */}
              <div className="bg-[#111] p-6 rounded-2xl border border-[#222] text-xs leading-relaxed text-gray-400">
                <h4 className="font-bold text-white mb-2 text-sm flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-[#ff6321]" />
                  كيفية استخدام الأكواد وشحنها في حسابك:
                </h4>
                <ol className="list-decimal list-inside space-y-2 pr-2 text-right">
                  <li>قم بنسخ كود الـ UC الذي حصلت عليه بنجاح من موقعنا.</li>
                  <li>توجه للموقع الرسمي المعتمد للشحن: <strong className="text-white">Midasbuy PUBG Mobile</strong>.</li>
                  <li>سجل دخولك وضع معرف لاعبك (Character ID) بدقة.</li>
                  <li>اختر خيار "استرداد" (Redeem) ثم الصق كود الشدات واضغط موافق لتصلك في بريد اللعبة فوراً!</li>
                </ol>
              </div>
            </div>
          )}

          {/* NEWS & OFFERS TAB CONTENT */}
          {activeTab === 'news' && (
            <div className="flex-1 flex flex-col gap-6" id="news-tab">
              {loading ? (
                <div className="py-20 text-center text-gray-500 font-bold">جاري تحميل الأخبار وعروض ببجي...</div>
              ) : data.news.length === 0 ? (
                <div className="py-16 text-center bg-[#111] rounded-2xl border border-dashed border-[#222]">
                  <TrendingUp className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                  <p className="text-gray-400 font-bold">لا توجد أخبار منشورة حالياً</p>
                  <p className="text-gray-600 text-xs mt-1">يتم متابعة اللعبة ووضع عروض وتحديثات بانتظام</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {data.news.map((item) => (
                    <article 
                      key={item.id}
                      className="border-2 border-[#222] hover:border-white/20 p-6 rounded-2xl bg-black/40 transition-colors"
                    >
                      <div className="flex flex-wrap gap-2 items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-black px-2.5 py-1 rounded skew-x-[-12deg] ${
                            item.category === 'offer' 
                              ? 'bg-[#ff6321] text-black' 
                              : 'bg-[#00ff00] text-black'
                          }`}>
                            {item.badge || (item.category === 'offer' ? "عرض ببجي" : "أخبار اللعبة")}
                          </span>
                          <span className="text-xs text-gray-500 font-mono">{item.dateAdded}</span>
                        </div>
                      </div>

                      <h3 className="text-xl font-bold text-white mb-2 leading-snug">
                        {item.title}
                      </h3>
                      <p className="text-sm text-gray-300 font-bold mb-4 bg-white/5 p-3 rounded-lg border-r-4 border-[#00ff00]">
                        {item.summary}
                      </p>
                      
                      <div className="text-xs text-gray-400 leading-relaxed whitespace-pre-line bg-black/30 p-4 rounded-xl border border-[#222]">
                        {item.content}
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ADMIN TAB / CONTROL PANEL */}
          {activeTab === 'admin' && (
            <div className="flex-1 flex flex-col gap-6" id="admin-tab">
              {!isAdminAuthenticated ? (
                <div className="max-w-md mx-auto w-full bg-[#111] p-8 rounded-2xl border-2 border-purple-500/30 shadow-2xl my-8">
                  <div className="text-center mb-6">
                    <div className="w-12 h-12 bg-purple-500/10 text-purple-400 rounded-full flex items-center justify-center mx-auto mb-3">
                      <Lock className="w-6 h-6" />
                    </div>
                    <h3 className="text-lg font-bold text-white">تسجيل دخول الإدارة (أدمن بروج فون)</h3>
                    <p className="text-xs text-gray-400 mt-1">أدخل الرمز السري للأدمن للوصول وإضافة الأكواد اليومية وتعديل الحساسية.</p>
                  </div>

                  <form onSubmit={handleAdminLogin} className="space-y-4">
                    <div>
                      <label className="block text-xs text-gray-400 mb-1.5 font-bold">الرمز السري الخاص بك (البين كود)</label>
                      <input
                        type="password"
                        placeholder="••••••"
                        value={adminPin}
                        onChange={(e) => setAdminPin(e.target.value)}
                        className="w-full bg-[#161616] border border-[#333] focus:border-purple-500 focus:ring-1 focus:ring-purple-500 rounded-xl px-4 py-3 text-center font-mono text-lg tracking-widest text-white focus:outline-none"
                        required
                      />
                      <span className="block text-[10px] text-gray-500 mt-1.5 text-center">الرمز الافتراضي للتجربة هو: <strong className="text-purple-400">123456</strong></span>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-3 rounded-xl text-xs transition-all cursor-pointer"
                    >
                      تسجيل دخول للوحة التحكم
                    </button>
                  </form>
                </div>
              ) : (
                <div className="flex flex-col gap-6">
                  {/* Admin inner tabs */}
                  <div className="flex flex-wrap gap-2 bg-[#111] p-2.5 rounded-xl border border-[#222]">
                    <button
                      onClick={() => { setAdminSection('sensitivities'); setEditingId(null); }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        adminSection === 'sensitivities' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      إدارة الحساسية
                    </button>
                    <button
                      onClick={() => { setAdminSection('controls'); setEditingId(null); }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        adminSection === 'controls' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      إدارة مخططات الأزرار
                    </button>
                    <button
                      onClick={() => { setAdminSection('news'); setEditingId(null); }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        adminSection === 'news' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      إدارة الأخبار وعروض ببجي
                    </button>
                    <button
                      onClick={() => { setAdminSection('uc'); setEditingId(null); }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        adminSection === 'uc' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      إدارة أكواد الـ UC
                    </button>
                    <button
                      onClick={() => { setAdminSection('settings'); setEditingId(null); }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        adminSection === 'settings' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      تغيير الرمز السري للأدمن
                    </button>
                  </div>

                  {/* SENSITIVITIES MANAGER */}
                  {adminSection === 'sensitivities' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      {/* Form to Add/Edit Sensitivity */}
                      <div className="lg:col-span-1 bg-[#111] p-6 rounded-2xl border border-purple-500/20">
                        <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-1.5">
                          <Plus className="w-4 h-4 text-purple-400" />
                          <span>{editingId ? "تعديل كود الحساسية الحالي" : "إضافة حساسية جديدة"}</span>
                        </h3>

                        <form onSubmit={handleSensSubmit} className="space-y-4 text-xs">
                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">العنوان الكامل للحساسية</label>
                            <input
                              type="text"
                              required
                              placeholder="مثال: حساسية جيروسكوب قوية شاومي 120 إطار"
                              value={sensForm.title}
                              onChange={(e) => setSensForm({...sensForm, title: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2.5 text-white"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-gray-400 mb-1 font-bold">نوع الأجهزة</label>
                              <select
                                value={sensForm.deviceType}
                                onChange={(e) => setSensForm({...sensForm, deviceType: e.target.value})}
                                className="w-full bg-[#161616] border border-[#333] rounded-lg p-2 text-white"
                              >
                                <option value="هواتف شاومي / بوكو">هواتف شاومي / بوكو</option>
                                <option value="هواتف سامسونج / عام">هواتف سامسونج / عام</option>
                                <option value="آيباد / تابلت">آيباد / تابلت</option>
                                <option value="أندرويد فئة متوسطة">أندرويد فئة متوسطة</option>
                              </select>
                            </div>

                            <div className="flex items-center gap-2 pt-5">
                              <input
                                type="checkbox"
                                id="isGyro"
                                checked={sensForm.isGyro}
                                onChange={(e) => setSensForm({...sensForm, isGyro: e.target.checked})}
                                className="w-4 h-4 rounded text-purple-600 focus:ring-0"
                              />
                              <label htmlFor="isGyro" className="text-gray-300 font-bold cursor-pointer">جايروسكوب نشط؟</label>
                            </div>
                          </div>

                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">كود الحساسية (ببجي موبايل)</label>
                            <input
                              type="text"
                              required
                              placeholder="مثال: 7124-8164-9271-2917-210"
                              value={sensForm.code}
                              onChange={(e) => setSensForm({...sensForm, code: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2.5 text-white font-mono"
                            />
                          </div>

                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">الوصف والتفاصيل</label>
                            <textarea
                              placeholder="ملاحظات حول الحساسية وثبات الأسلحة والسكوبات..."
                              value={sensForm.description}
                              rows={2}
                              onChange={(e) => setSensForm({...sensForm, description: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2 text-white"
                            />
                          </div>

                          {/* Stats customization */}
                          <div className="bg-black/40 p-3 rounded-lg border border-[#222]">
                            <span className="block text-purple-400 font-bold mb-2">تعديل نسب الحساسية الرقمية</span>
                            <div className="grid grid-cols-3 gap-2">
                              <div>
                                <label className="text-[10px] text-gray-500">كاميرا</label>
                                <input
                                  type="text"
                                  value={sensForm.camera}
                                  onChange={(e) => setSensForm({...sensForm, camera: e.target.value})}
                                  className="w-full bg-[#222] border border-[#444] rounded p-1 text-center font-mono"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-gray-500">ADS</label>
                                <input
                                  type="text"
                                  value={sensForm.ads}
                                  onChange={(e) => setSensForm({...sensForm, ads: e.target.value})}
                                  className="w-full bg-[#222] border border-[#444] rounded p-1 text-center font-mono"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-gray-500">جايرو</label>
                                <input
                                  type="text"
                                  disabled={!sensForm.isGyro}
                                  value={sensForm.gyro}
                                  onChange={(e) => setSensForm({...sensForm, gyro: e.target.value})}
                                  className="w-full bg-[#222] border border-[#444] rounded p-1 text-center font-mono disabled:opacity-40"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-2 mt-2">
                              <div>
                                <label className="text-[10px] text-gray-500">سكوب 3x</label>
                                <input
                                  type="text"
                                  value={sensForm.scope3x}
                                  onChange={(e) => setSensForm({...sensForm, scope3x: e.target.value})}
                                  className="w-full bg-[#222] border border-[#444] rounded p-1 text-center font-mono"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-gray-500">سكوب 4x</label>
                                <input
                                  type="text"
                                  value={sensForm.scope4x}
                                  onChange={(e) => setSensForm({...sensForm, scope4x: e.target.value})}
                                  className="w-full bg-[#222] border border-[#444] rounded p-1 text-center font-mono"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-gray-500">سكوب 6x</label>
                                <input
                                  type="text"
                                  value={sensForm.scope6x}
                                  onChange={(e) => setSensForm({...sensForm, scope6x: e.target.value})}
                                  className="w-full bg-[#222] border border-[#444] rounded p-1 text-center font-mono"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="flex gap-2 pt-2">
                            <button
                              type="submit"
                              className="flex-1 bg-purple-600 hover:bg-purple-500 text-white font-bold py-2 rounded-lg transition-all cursor-pointer"
                            >
                              {editingId ? "تحديث الحساسية" : "إضافة الكود فوراً"}
                            </button>
                            {editingId && (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingId(null);
                                  setSensForm({
                                    title: '', deviceType: 'هواتف شاومي / بوكو', code: '', description: '', isGyro: true,
                                    camera: '120%', ads: '115%', gyro: '320%', scope3x: '200%', scope4x: '160%', scope6x: '90%'
                                  });
                                }}
                                className="bg-gray-700 text-white px-3 rounded-lg"
                              >
                                إلغاء
                              </button>
                            )}
                          </div>
                        </form>
                      </div>

                      {/* Display existing sensitivities in tabular/list with Delete/Edit buttons */}
                      <div className="lg:col-span-2 bg-[#111] p-6 rounded-2xl border border-gray-800">
                        <h3 className="text-sm font-bold text-white mb-4">أكواد الحساسية المضافة حالياً ({data.sensitivities.length})</h3>
                        <div className="space-y-3">
                          {data.sensitivities.map((sens) => (
                            <div key={sens.id} className="bg-black/50 p-4 rounded-xl border border-gray-800 flex justify-between items-center text-xs">
                              <div>
                                <p className="font-bold text-white text-sm">{sens.title}</p>
                                <p className="text-gray-500 mt-1">النوع: {sens.deviceType} • الكود: <span className="text-purple-400 font-mono">{sens.code}</span></p>
                              </div>
                              <div className="flex gap-2 shrink-0">
                                <button
                                  onClick={() => startEditSens(sens)}
                                  className="p-2 bg-blue-950/40 text-blue-400 hover:text-white rounded-lg border border-blue-900 transition-colors cursor-pointer"
                                  title="تعديل"
                                >
                                  <Edit className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => handleSensDelete(sens.id)}
                                  className="p-2 bg-red-950/40 text-red-400 hover:text-white rounded-lg border border-red-900 transition-colors cursor-pointer"
                                  title="حذف"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* CONTROLS MANAGER */}
                  {adminSection === 'controls' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      {/* Form */}
                      <div className="lg:col-span-1 bg-[#111] p-6 rounded-2xl border border-purple-500/20">
                        <h3 className="text-sm font-bold text-white mb-4">إضافة مخطط أزرار جديد</h3>
                        <form onSubmit={handleControlSubmit} className="space-y-4 text-xs">
                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">عنوان المخطط</label>
                            <input
                              type="text"
                              required
                              placeholder="مثال: كود أزرار 4 أصابع جيروسكوب بوجي"
                              value={controlForm.title}
                              onChange={(e) => setControlForm({...controlForm, title: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2.5 text-white"
                            />
                          </div>

                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">نوع المخطط</label>
                            <select
                              value={controlForm.layoutType}
                              onChange={(e) => setControlForm({...controlForm, layoutType: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2 text-white"
                            >
                              <option value="إصبعين">إصبعين</option>
                              <option value="3 أصابع">3 أصابع</option>
                              <option value="4 أصابع">4 أصابع</option>
                              <option value="5 أصابع">5 أصابع</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">كود تخطيط الأزرار ببجي</label>
                            <input
                              type="text"
                              required
                              placeholder="مثال: 1234-5678-9012-3456-789"
                              value={controlForm.code}
                              onChange={(e) => setControlForm({...controlForm, code: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2.5 text-white font-mono"
                            />
                          </div>

                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">الوصف والتوزيع بالأصابع</label>
                            <textarea
                              required
                              placeholder="اكتب تفاصيل توزيع زر الإطلاق والحركة وزر فتح السكوب..."
                              value={controlForm.description}
                              rows={3}
                              onChange={(e) => setControlForm({...controlForm, description: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2 text-white"
                            />
                          </div>

                          <button
                            type="submit"
                            className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-2.5 rounded-lg transition-all cursor-pointer"
                          >
                            حفظ مخطط اللعب
                          </button>
                        </form>
                      </div>

                      {/* List */}
                      <div className="lg:col-span-2 bg-[#111] p-6 rounded-2xl border border-gray-800">
                        <h3 className="text-sm font-bold text-white mb-4">مخططات اللعب الحالية ({data.controls.length})</h3>
                        <div className="space-y-3">
                          {data.controls.map((layout) => (
                            <div key={layout.id} className="bg-black/50 p-4 rounded-xl border border-gray-800 flex justify-between items-center text-xs">
                              <div>
                                <p className="font-bold text-white text-sm">{layout.title}</p>
                                <p className="text-gray-500 mt-1">النمط: {layout.layoutType} • الكود: <span className="text-purple-400 font-mono">{layout.code}</span></p>
                              </div>
                              <button
                                onClick={() => handleControlDelete(layout.id)}
                                className="p-2 bg-red-950/40 text-red-400 hover:text-white rounded-lg border border-red-900 transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* NEWS & OFFERS MANAGER */}
                  {adminSection === 'news' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      {/* Form */}
                      <div className="lg:col-span-1 bg-[#111] p-6 rounded-2xl border border-purple-500/20">
                        <h3 className="text-sm font-bold text-white mb-4">نشر خبر أو عرض ببجي جديد</h3>
                        <form onSubmit={handleNewsSubmit} className="space-y-4 text-xs">
                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">العنوان</label>
                            <input
                              type="text"
                              required
                              placeholder="عنوان منشور ببجي موبايل..."
                              value={newsForm.title}
                              onChange={(e) => setNewsForm({...newsForm, title: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2.5 text-white"
                            />
                          </div>

                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">ملخص قصير</label>
                            <input
                              type="text"
                              placeholder="ملخص يظهر بالأعلى..."
                              value={newsForm.summary}
                              onChange={(e) => setNewsForm({...newsForm, summary: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2.5 text-white"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-gray-400 mb-1 font-bold">التصنيف</label>
                              <select
                                value={newsForm.category}
                                onChange={(e) => setNewsForm({...newsForm, category: e.target.value as 'news' | 'offer'})}
                                className="w-full bg-[#161616] border border-[#333] rounded-lg p-2 text-white"
                              >
                                <option value="news">أخبار عادية</option>
                                <option value="offer">عروض الشحن والهدايا</option>
                              </select>
                            </div>
                            <div>
                              <label className="block text-gray-400 mb-1 font-bold">شارة تمييز المنشور</label>
                              <input
                                type="text"
                                placeholder="مثال: عرض محدود"
                                value={newsForm.badge}
                                onChange={(e) => setNewsForm({...newsForm, badge: e.target.value})}
                                className="w-full bg-[#161616] border border-[#333] rounded-lg p-2 text-white"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">محتوى الخبر بالكامل</label>
                            <textarea
                              required
                              placeholder="اكتب المقال أو الخبر هنا بالتفصيل..."
                              value={newsForm.content}
                              rows={5}
                              onChange={(e) => setNewsForm({...newsForm, content: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2 text-white"
                            />
                          </div>

                          <button
                            type="submit"
                            className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-2.5 rounded-lg transition-all cursor-pointer"
                          >
                            نشر المقال
                          </button>
                        </form>
                      </div>

                      {/* List */}
                      <div className="lg:col-span-2 bg-[#111] p-6 rounded-2xl border border-gray-800">
                        <h3 className="text-sm font-bold text-white mb-4">المقالات المنشورة حالياً ({data.news.length})</h3>
                        <div className="space-y-3">
                          {data.news.map((item) => (
                            <div key={item.id} className="bg-black/50 p-4 rounded-xl border border-gray-800 flex justify-between items-center text-xs">
                              <div>
                                <p className="font-bold text-white text-sm">{item.title}</p>
                                <p className="text-gray-500 mt-1">التصنيف: {item.category === 'offer' ? 'عرض ببجي' : 'خبر ببجي'} • التاريخ: {item.dateAdded}</p>
                              </div>
                              <button
                                onClick={() => handleNewsDelete(item.id)}
                                className="p-2 bg-red-950/40 text-red-400 hover:text-white rounded-lg border border-red-900 transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* UC CODES MANAGER */}
                  {adminSection === 'uc' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      {/* Form */}
                      <div className="lg:col-span-1 bg-[#111] p-6 rounded-2xl border border-purple-500/20">
                        <h3 className="text-sm font-bold text-white mb-4">توليد وإضافة كود شدات UC مجاني</h3>
                        <form onSubmit={handleUcSubmit} className="space-y-4 text-xs">
                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">قيمة الشدات</label>
                            <select
                              value={ucForm.value}
                              onChange={(e) => setUcForm({...ucForm, value: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2.5 text-white"
                            >
                              <option value="60 UC">60 UC</option>
                              <option value="325 UC">325 UC</option>
                              <option value="660 UC">660 UC</option>
                              <option value="1800 UC">1800 UC</option>
                              <option value="3850 UC">3850 UC</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-gray-400 mb-1 font-bold">كود الشحن الفردي</label>
                            <input
                              type="text"
                              required
                              placeholder="مثال: PROG-PUBG-60UC-K8X9"
                              value={ucForm.code}
                              onChange={(e) => setUcForm({...ucForm, code: e.target.value})}
                              className="w-full bg-[#161616] border border-[#333] rounded-lg p-2.5 text-white font-mono"
                            />
                            <p className="text-[10px] text-gray-500 mt-1">يجب أن يكون الكود مميزاً ويشحن مرة واحدة.</p>
                          </div>

                          <div className="flex items-center gap-2 pt-1">
                            <input
                              type="checkbox"
                              id="isAvailable"
                              checked={ucForm.isAvailable}
                              onChange={(e) => setUcForm({...ucForm, isAvailable: e.target.checked})}
                              className="w-4 h-4 text-purple-600 focus:ring-0 rounded"
                            />
                            <label htmlFor="isAvailable" className="text-gray-300 font-bold cursor-pointer">متاح للاستخدام الفوري للزوار؟</label>
                          </div>

                          <button
                            type="submit"
                            className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-2.5 rounded-lg transition-all cursor-pointer"
                          >
                            إضافة كود الـ UC للسيرفر
                          </button>
                        </form>
                      </div>

                      {/* List */}
                      <div className="lg:col-span-2 bg-[#111] p-6 rounded-2xl border border-gray-800">
                        <h3 className="text-sm font-bold text-white mb-4">كروت الشدات المتاحة للزوار ({data.ucCodes.length})</h3>
                        <div className="space-y-3">
                          {data.ucCodes.map((uc) => (
                            <div key={uc.id} className="bg-black/50 p-4 rounded-xl border border-gray-800 flex justify-between items-center text-xs">
                              <div>
                                <p className="font-bold text-white text-sm">{uc.value} — <span className="font-mono text-[#00ff00]">{uc.code}</span></p>
                                <p className="text-gray-500 mt-1">
                                  الحالة: {uc.isAvailable ? <span className="text-emerald-400">متوفر</span> : <span className="text-red-400">تم استلامه</span>}
                                </p>
                              </div>
                              <button
                                onClick={() => handleUcDelete(uc.id)}
                                className="p-2 bg-red-950/40 text-red-400 hover:text-white rounded-lg border border-red-900 transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* ADMIN SECURITY / SETTINGS */}
                  {adminSection === 'settings' && (
                    <div className="max-w-md mx-auto w-full bg-[#111] p-6 rounded-2xl border border-purple-500/20">
                      <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-1.5">
                        <Lock className="w-4 h-4 text-purple-400" />
                        <span>تغيير كود الأدمن السري</span>
                      </h3>

                      <form onSubmit={handleChangePin} className="space-y-4 text-xs">
                        <div>
                          <label className="block text-gray-400 mb-1.5 font-bold">الرمز السري الجديد (على الأقل 4 حروف أو أرقام)</label>
                          <input
                            type="text"
                            required
                            placeholder="ضع الرمز الجديد..."
                            value={newPin}
                            onChange={(e) => setNewPin(e.target.value)}
                            className="w-full bg-[#161616] border border-[#333] focus:border-purple-500 rounded-lg p-2.5 font-mono text-white text-center"
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-2.5 rounded-lg transition-all cursor-pointer"
                        >
                          تغيير كود الأدمن الآن
                        </button>
                      </form>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

        </section>

        {/* LEFT PANEL: UC Quick and News highlights */}
        <aside className="w-full lg:w-80 border-t-2 lg:border-t-0 lg:border-r-2 border-[#1f1f1f] bg-black/60 p-4 sm:p-6 flex flex-col gap-6 shrink-0" id="side-panel">
          
          {/* Quick free reward card */}
          <div className="p-5 border-2 border-[#ff6321] rounded-2xl relative overflow-hidden bg-black/85">
            <div className="text-[#ff6321] text-xs font-black uppercase mb-1 tracking-wider flex items-center gap-1">
              <Sparkles className="w-4 h-4 text-[#ff6321]" />
              <span>أحدث كود شدات مجاني</span>
            </div>
            
            {data.ucCodes.filter(u => u.isAvailable).length > 0 ? (
              (() => {
                const availableCode = data.ucCodes.filter(u => u.isAvailable)[0];
                return (
                  <>
                    <div className="font-bold text-sm text-gray-300 mt-2">كود شحن {availableCode.value} مجاناً</div>
                    <div className="font-mono text-lg font-black text-white mt-1 mb-4 tracking-wider">{availableCode.code}</div>
                    <button 
                      onClick={() => handleClaimUCCode(availableCode.id)}
                      className="w-full bg-[#ff6321] hover:bg-orange-500 text-black font-black py-2.5 rounded-xl text-xs uppercase tracking-wider transition-all duration-200 cursor-pointer"
                    >
                      حجز الكود الآن
                    </button>
                  </>
                );
              })()
            ) : (
              <>
                <div className="font-bold text-sm text-gray-400 mt-2">عفواً، تم استرداد جميع الأكواد الحالية</div>
                <div className="text-xs text-gray-600 mt-1 mb-4">يقوم الأدمن بإضافة كروت جديدة كل يوم! ارجع لاحقاً.</div>
                <button 
                  onClick={() => setActiveTab('uc')}
                  className="w-full bg-[#222] text-gray-400 hover:text-white font-bold py-2 text-xs rounded-xl border border-[#333] transition-all cursor-pointer"
                >
                  استعراض سجل الأكواد
                </button>
              </>
            )}
            
            <div className="absolute -bottom-4 -left-4 text-7xl opacity-[0.03] font-black italic pointer-events-none select-none">
              PUBG
            </div>
          </div>

          {/* Quick News highlights widget */}
          <div className="flex-1 flex flex-col" id="side-news">
            <div className="text-[10px] text-gray-500 uppercase tracking-widest mb-4 font-bold">آخر منشورات وعروض بروج فون</div>
            
            {loading ? (
              <div className="text-xs text-gray-500">جاري فحص آخر الأخبار...</div>
            ) : data.news.length === 0 ? (
              <div className="text-xs text-gray-600">لا توجد أخبار اليوم.</div>
            ) : (
              <div className="space-y-4">
                {data.news.slice(0, 3).map((item) => (
                  <div 
                    key={item.id} 
                    onClick={() => setActiveTab('news')}
                    className="group cursor-pointer p-3 rounded-xl border border-transparent hover:border-white/10 hover:bg-white/5 transition-all"
                  >
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-[9px] font-mono text-[#00ff00] bg-[#00ff00]/10 px-1.5 py-0.5 rounded">
                        {item.dateAdded}
                      </span>
                      <span className="text-[9px] text-gray-500">
                        {item.category === 'offer' ? 'عروض الشحن' : 'تحديث اللعبة'}
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-white group-hover:text-[#00ff00] transition-colors line-clamp-2 leading-relaxed">
                      {item.title}
                    </h4>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Android specifications recommendation notes */}
          <div className="p-4 bg-[#111] rounded-xl border border-dashed border-gray-800 text-[11px] text-gray-400">
            <div className="text-[9px] text-gray-500 mb-1 italic font-bold">بروج فون للأندرويد:</div>
            <p className="leading-relaxed">
              جميع الأكواد المنشورة يتم اختبارها بدقة على أجهزة سناب دراجون، ميديا تيك هيلو، وإكسينوس لضمان معدل إطارات مستقر 60/90 إطار ومستوى استجابة فائق.
            </p>
          </div>
        </aside>
      </main>

      {/* Bottom News Ticker / Footer (Artistic Flair Marquee style) */}
      <footer className="h-12 bg-[#00ff00] text-black flex items-center overflow-hidden border-t-2 border-black relative" id="main-footer">
        <div className="absolute inset-0 flex items-center">
          <div className="whitespace-nowrap flex items-center gap-16 px-6 font-extrabold text-xs sm:text-sm uppercase italic animate-[marquee_25s_linear_infinite] select-none">
            <span>🚀 موقع بروج فون: الموقع الأول لأكواد ببجي موبايل المجربة في الوطن العربي</span>
            <span>🔥 جديد: تم إضافة أكواد شدات مجانية (UC) الآن - استلم هديتك اليومية</span>
            <span>🎮 تم تحديث الحساسية اليومية لأجهزة شاومي وسامسونج وآيباد بنجاح</span>
            <span>📱 السيرفر الخارجي يعمل بكفاءة ومزامنة تلقائية 100% مع اللعبة</span>
            <span>🔧 يمكنك الدخول إلى لوحة الأدمن برمز الأمان لتعديل وإضافة الحساسية فورياً</span>
          </div>
        </div>
        
        {/* Custom inline style for marquee keyframes animation so it works without tailwind.config customization */}
        <style>{`
          @keyframes marquee {
            0% { transform: translateX(50%); }
            100% { transform: translateX(-100%); }
          }
        `}</style>
      </footer>
    </div>
  );
}
