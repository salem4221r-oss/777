import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Clipboard, Check } from 'lucide-react';

interface CopyButtonProps {
  text: string;
  label?: string;
  className?: string;
}

export default function CopyButton({ text, label, className = "" }: CopyButtonProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy!", err);
    }
  };

  return (
    <button
      onClick={handleCopy}
      className={`relative overflow-hidden flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold transition-all active:scale-95 duration-200 cursor-pointer ${
        copied
          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
          : 'bg-orange-600 hover:bg-orange-500 text-white shadow-lg shadow-orange-600/20'
      } ${className}`}
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={copied ? "copied" : "copy"}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.15 }}
          className="flex items-center gap-1.5"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4" />
              <span>تم النسخ!</span>
            </>
          ) : (
            <>
              <Clipboard className="w-4 h-4" />
              <span>{label || "نسخ الكود"}</span>
            </>
          )}
        </motion.span>
      </AnimatePresence>
    </button>
  );
}
